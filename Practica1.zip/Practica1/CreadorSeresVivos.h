#ifndef CREADORSERESVIVOS_H
#define CREADORSERESVIVOS_H

#include "Creador.h"

class CreadorSerVivo : public Creador {
public:
    virtual SeresVivos* crearSerVivo() override;
};


#endif 
