#include "Ave.h";
#include <iostream>

void Ave::nacer() {
    std::cout << "Un ave nace." << std::endl;
}

void Ave::crecer() {
    std::cout << "Un ave crece." << std::endl;
}

void Ave::reproducirse() {
    std::cout << "Un ave se reproduce." << std::endl;
}

void Ave::morir() {
    std::cout << "Un ave muere." << std::endl;
}

void Ave::volar() {
    std::cout << "Un ave esta volando..." << std::endl;
}
    
void Ave::cambiarDimension() {
    std::cout << "Un ave No puede cambiar de dimension." << std::endl;
}