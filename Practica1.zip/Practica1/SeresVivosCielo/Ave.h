#include "SerCielo.h"

class Ave : public SerCielo { 
public:
    void nacer() override;
    void crecer() override;
    void reproducirse() override;
    void morir() override;
    void volar() override;
    void cambiarDimension() override;
};
