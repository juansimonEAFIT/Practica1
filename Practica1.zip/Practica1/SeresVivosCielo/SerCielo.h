#ifndef SERCIELO_H
#define SERCIELO_H

#include "../SeresVivos.h"

//"Interfaz" ser del cielo
class SerCielo : public SeresVivos {
public:

private:
    virtual void volar();
    virtual void cambiarDimension();
};

#endif
