#include <iostream>

#include "CreadorSeresVivos.h"
#include "SeresVivos.h"

SeresVivos* CreadorSeresVivos::crearSerVivo() {

    if (tipo.equals("Humano")) {
        return new SerTierra.Humano();
    }
    else if (tipo.equals("Animal")) {
        return new SerTierra.Animal();
    }
    else if (tipo.equals("Ave")) {
        return new SerCielo.Ave();
    }
    return nullptr;
}

