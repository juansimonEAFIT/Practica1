#ifndef CREADOR_H
#define CREADOR_H

#include "SeresVivos.h"

// "Interfaz" Creator
class Creador {
public:
    virtual SeresVivos* crearSerVivo();
};

#endif
