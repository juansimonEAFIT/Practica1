#ifndef SERESVIVOS_H
#define SERESVIVOS_H

class SeresVivos {
    public:
        virtual void nacer ();
        virtual void crecer ();
        virtual void reproducirse();
        virtual void morir ();
};

#endif
