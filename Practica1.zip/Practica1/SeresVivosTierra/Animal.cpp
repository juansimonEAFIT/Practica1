#include "Animal.h"
#include <iostream>

void Animal::nacer() {
    std::cout << "Un Animal nace." << std::endl;
}

void Animal::crecer() {
    std::cout << "Un Animal crece." << std::endl;
}

void Animal::regenerarse() {
    std::cout << "Un Animal se regenera." << std::endl;
}

void Animal::morir() {
    std::cout << "Un Animal muere." << std::endl;
}
