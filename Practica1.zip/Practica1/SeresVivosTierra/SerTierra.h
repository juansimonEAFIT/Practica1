#ifndef SERTIERRA_H
#define SERTIERRA_H

#include "../SeresVivos.h"

//"Interfaz" ser de la tierra
class SerTierra : public SeresVivos {
public:
    virtual void regenerarse();
};

#endif
