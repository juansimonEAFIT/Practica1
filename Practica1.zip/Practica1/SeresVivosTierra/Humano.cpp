#include "Humano.h"
#include <iostream>

void Humano::nacer() {
    std::cout << "Un humano nace." << std::endl;
}

void Humano::crecer() {
    std::cout << "Un humano crece." << std::endl;
}

void Humano::regenerarse() {
    std::cout << "Un humano se regenera." << std::endl;
}

void Humano::morir() {
    std::cout << "Un humano muere." << std::endl;
}

void Humano::volar() {
    std::cout << "Un humano va en avion." << std::endl;
}

void Humano::cambiarDimension() {
    std::cout << "Un humano No puede cambiar de dimension." << std::endl;
}