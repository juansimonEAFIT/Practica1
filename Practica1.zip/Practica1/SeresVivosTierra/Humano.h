#ifndef HUMANO_H
#define HUMANO_H

#include <iostream>
using namespace std;

#include "SerTierra.h"
#include "../SeresVivosCielo/SerCielo.h"

// Clase humano
class Humano : public SerTierra, public SerCielo {
public:

    Humano();

    void nacer() override;
    void crecer() override;
    void reproducirse() override;
    void regenerarse() override;
    void morir() override;
    void volar() override;
    void cambiarDimension() override;

};

#endif
