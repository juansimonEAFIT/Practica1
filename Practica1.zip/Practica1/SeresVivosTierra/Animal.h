#ifndef ANIMAL_H
#define ANIMAL_H


#include "SerTierra.h"

class Animal : public SerTierra{
public:

    Animal();

    void nacer() override;
    void crecer() override;
    void reproducirse() override;
    void regenerarse() override;
    void morir() override;

};

#endif
