#include <iostream>

#include "CreadorSeresVivos.h"
#include "Creador.h"
#include "../SeresVivosTierra/Humano.h"
#include "../SeresVivosCielo/Ave.h"

int main() {

    CreadorSerVivo Creador;

    SerTierra* humano = new SerTierra();

    humano->nacer();
    humano->crecer();
    humano->regenerarse();
    humano->morir();

    delete humano;

    SerCielo* ave = new SerCielo();

    ave->nacer();
    ave->crecer();
    ave->reproducirse();
    ave->morir();

    delete ave;

    SerTierra* animal = new SerTierra();

    animal->nacer();
    animal->crecer();
    animal->regenerarse();
    animal->morir();

    delete animal;



    return 0;
}
